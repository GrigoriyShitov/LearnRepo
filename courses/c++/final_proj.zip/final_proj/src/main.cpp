#include "../include/Output.h"
#include <bits/stdc++.h>

int main()
{
    CLI c;
    c.StartCLI();
  
    return 0;
}