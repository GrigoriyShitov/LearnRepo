#ifndef TASK3_H
#define TASK3_H

#include "student.h"

namespace task3
{
    extern Student arr[5];

    void Do();
    Student findBestStudent();
    void printStudent(bool bEndl);
    void printStudent();
}

#endif