#ifndef TASK1_H
#define TASK1_H

#include "point.h"
#include <iostream>
#include <cmath>

namespace task1{
    void Do();
    int distance(Point p1, Point p2);
}

#endif