#ifndef TASK4_H
#define TASK4_H

#include "library.h"

namespace task4{
    void Do();
}

#endif