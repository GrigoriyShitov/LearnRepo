#ifndef TASK2_H
#define TASK2_H

#include "student.h"

namespace task2
{
    void Do();
}
#endif