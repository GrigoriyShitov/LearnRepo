#include <iostream>
#include "../include/task1.h"
#include "../include/task2.h"
#include "../include/task3.h"
#include "../include/task4.h"
#include "../include/task6.h"

int main(int, char **)
{
    task1::Do();
    task2::Do();
    task3::Do();
    task4::Do();
    task6::Do();
    return 0;
}
