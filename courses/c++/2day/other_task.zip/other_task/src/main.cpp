#include <iostream>
#include "../include/task2.hpp"
#include "../include/task3.h"
#include "../include/task4.h"

int main(){
    // Task2::Do();
    // Task3::Do();
    Task2::DoTask4();
    return 0;
}