#include <cstdlib>
#include <ctime>
#include <iostream>

namespace Task2{
    void fillArray(int arr[],int size);
    void printArray(int arr[],int size);
    void Do();
}