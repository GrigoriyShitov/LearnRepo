#include <iostream>
#include <cstdlib>
#include <ctime>
#include "task2.hpp"

namespace Task3{
    void Do();
    void fillArray(int arr[],int size);
    void countAndSum(int arr[],int size, int x);
}