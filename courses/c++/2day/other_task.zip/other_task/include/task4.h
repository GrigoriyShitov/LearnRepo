#include <iostream>
#include <cstdlib>
#include <ctime>
#include "task2.hpp"


namespace Task2{
    void DoTask4();
    void sortArray(int arr[], int size);
}