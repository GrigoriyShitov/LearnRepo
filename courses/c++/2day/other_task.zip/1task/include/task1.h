
namespace task1{
    void Do();
}
