#include <iostream>
#include "../include/task1.h"

int main(){
    task1::Do();
    return 0;
}